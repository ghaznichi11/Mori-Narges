# Mori × Narges Countdown ❤️

A small romantic countdown website for Mori and Narges.

Target date: **12 September 2026**

## Important
The current version stores notes in the browser's `localStorage`, so it is a working preview but **not yet a shared database**.

Next step: connect Firebase (free tier) so both people can open the GitHub Pages URL and see/add the same notes.

## GitHub Pages
After uploading the files:
1. Repository → Settings
2. Pages
3. Source: Deploy from a branch
4. Branch: `main` / `/ (root)`
5. Save
