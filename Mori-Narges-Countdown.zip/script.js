const TARGET = new Date("2026-09-12T00:00:00+02:00").getTime();
const KEY = "mori_narges_notes_v1";
const $ = id => document.getElementById(id);

function tick(){
  const diff = Math.max(0, TARGET - Date.now());
  const d=Math.floor(diff/86400000);
  const h=Math.floor(diff%86400000/3600000);
  const m=Math.floor(diff%3600000/60000);
  const s=Math.floor(diff%60000/1000);
  $("days").textContent=String(d);
  $("hours").textContent=String(h).padStart(2,"0");
  $("minutes").textContent=String(m).padStart(2,"0");
  $("seconds").textContent=String(s).padStart(2,"0");
}
function load(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}}
function save(list){localStorage.setItem(KEY,JSON.stringify(list))}
function render(){
  const notes=load();
  $("noteCount").textContent=`${notes.length} یادداشت`;
  $("notesList").innerHTML=notes.length ? notes.slice().reverse().map(n=>`
    <article class="note">
      <div class="meta">${n.day} • ${n.date}</div>
      <p>${escapeHtml(n.text).replace(/\n/g,"<br>")}</p>
    </article>`).join("") : `<div class="empty">هنوز یادداشتی ثبت نشده… اولینش را بنویسید 🌙</div>`;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function dayNo(){
  const start=new Date("2026-08-13T00:00:00+02:00");
  const now=new Date();
  return Math.max(1,Math.floor((now-start)/86400000)+1);
}
$("dayNumber").textContent=`Day ${dayNo()}`;
$("year").textContent=new Date().getFullYear();
$("saveBtn").addEventListener("click",()=>{
  const text=$("noteInput").value.trim();
  if(!text){$("status").textContent="اول یک یادداشت بنویس ❤️";return}
  const now=new Date();
  const notes=load();
  notes.push({text,day:`Day ${dayNo()}`,date:now.toLocaleDateString("fa-IR")});
  save(notes);
  $("noteInput").value="";
  $("status").textContent="ذخیره شد ❤️";
  render();
  setTimeout(()=>$("status").textContent="",1800);
});
tick(); setInterval(tick,1000); render();
